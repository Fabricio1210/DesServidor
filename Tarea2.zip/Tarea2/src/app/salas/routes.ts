import { Router } from "express";
import { renderSala } from "./controller";

const router = Router()

router.get('', renderSala);

export default router