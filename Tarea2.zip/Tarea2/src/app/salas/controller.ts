import { Request, Response } from "express";

export function renderSala(req:Request, res:Response){
    res.render('salas');
}